# importing necessary modules
import requests, zipfile
from io import BytesIO
import os
print('Downloading started')
print('123456')

#Defining the zip file URL
url = 'https://github.com/nt-vu/nt-vu/raw/main/B30.zip'

# Split URL to get the file name
filename = url.split('/')[-1]

# Downloading the file by sending the request to the URL
req = requests.get(url)
print('Downloading Completed')

# extracting the zip file contents
zipfile= zipfile.ZipFile(BytesIO(req.content))
zipfile.extractall(f'{os.getcwd()}')


