from tkinter import *
import random
from tkinter.filedialog import askopenfile




def run():
	# value = wordInp.get("1.0","end-1c").split('\n')
	# i = randint(0, len(value)-1)
	i = random.choice(list(a.keys()))
	result['text'] = i

def chooseLesson():
	file = askopenfile(parent=root, mode='r', title='Choose a file',filetype=[('Text file','*')])
	f = open(file.name,'r', encoding='utf-8')
	content = ''.join(f.readlines())
	wordInp.delete(1.0,"end")
	wordInp.insert(1.0, content)

def setData():
	global a
	a = dict()
	fileName = chooseLessonValues.get() + '.txt'
	f = open(fileName,"r",encoding="utf-8")
	l = f.read().strip()
	f.close()

	
	for i in l.split('\n'):
		w = i.split(':')
		a[w[0].strip()] = w[1].strip()

def showAns():
	result['text'] += f"\n\n{a[result['text']]}"


a = dict()
root = Tk()
root.title('Random')
root.geometry('800x500')
root.configure(background='#E5E5E5')


version = '1.0'
title = Label (root, text = f'N i h o n g o {version}', font='Helvetica 16 bold italic', bg='#E5E5E5')
title.pack(pady=10)

# chooseLessonBtn = Button(root, text='Choose Lesson', font='Helvetica 10', command=chooseLesson)
# chooseLessonBtn.pack(anchor=W, padx=12)

OPTIONS = [
		"B26",
		"B27",
		"B28",
		"B29",
		"B30"
	]

header = Frame(root,background='#E5E5E5')
header.pack(anchor=W)

chooseLessonValues = StringVar(root)
chooseLessonValues.set("Choose lesson")
chooseLessonBtn = OptionMenu(header, chooseLessonValues, *OPTIONS)
chooseLessonBtn.config(width=12)
chooseLessonBtn.pack(side=LEFT, padx=12)

cfLessonBtn = Button(header, text="OK", command=setData, font=("Helvetica",10))
cfLessonBtn.pack(side=LEFT)


result = Label(root,bg="#a4b0be",fg="#000",text="Enter random to start",font=("Helvetica",20), height=8, width=30, borderwidth=2, relief='groove', wraplength=380)
result.pack(pady=20, padx=10)


submit = Button(root, text='Random', command=run, font=("Helvetica",12))
submit.pack( ipadx=20, padx=10)

checkanswerBtn = Button(root, text='Answer', command=showAns, font=("Helvetica",11))
checkanswerBtn.pack(ipadx=0, padx=10, pady=10)






root.mainloop()



	